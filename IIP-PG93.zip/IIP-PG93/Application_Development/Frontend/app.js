// Require express to make easy
// routing on server side.
const express = require("express");

// Creating express object
const app = express();
const mongodb = require("mongodb").MongoClient;
const csvtojson = require("csvtojson");
var formidable = require("formidable");
var fs = require("fs");
// Require path module
const path = require('path');

// Require pug template engine
var bodyParser=require("body-parser");

// Require mongoose to use mongoDb
// in a easier way
const mongoose = require("mongoose");

const { check, validationResult } = require('express-validator');
const { send } = require("process");

// Define a port number
const port = 3000;

const bcrypt = require ("bcryptjs");
const { time } = require("console");
const { sanitize } = require("express-validator");

app.use(express.urlencoded({extended : false}))

// Make a static route to use your
// static files in client side
app.use('/static', express.static('static'));

// Middleware for parsing
app.use(express.urlencoded());

// Define and use pug engine so also
// declare path on rendering
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Database Connection
mongoose.connect(
	"mongodb://localhost:27017/Online_Feedback_System",
	{ useUnifiedTopology: true }
);
var db=mongoose.connection;
db.on('error', console.log.bind(console, "connection error"));
db.once('open', function(callback){
	console.log("connection succeeded");
})

// Create schema
const feedback_Schecma = mongoose.Schema({
	studentId: 	Number,
	educatorId: Number,
	date: String,
	
	subject: String,
	presenting: Number,
	friendly: Number,
	efficiency: Number,
	Time_Utilization: Number,
	Examples: Number,
	Knowledge: Number,
	Doubts: Number,
	Suggestions	: String

});
mongoose.connect(
	"mongodb://localhost:27017/Online_Feedback_System",
	{ useUnifiedTopology: true }
);
const feedback_Schecma2 = mongoose.Schema({
	studentId:  Number,
	date: String,
		techAssociateId: Number,
		subject: String,
helping: Number,
	handling: Number,
	guiding: Number,
	DoubtClarrifying: Number,
	Availability: Number,
	Choosing: Number,
	
	Suggestions	: String

});
// Making a modal on our already
// defined schema

const feedback_Modal = mongoose.model('tbl_E_Feedback123', feedback_Schecma);
app.get('/', function (req, res) {
		// Rendering your form
		res.render('login');
	});
	const feedback_Modal2 = mongoose.model('tbl_Tech_Feedback123', feedback_Schecma2);

	app.get('/home', function (req, res) {
		// Rendering your form
		res.render('home');
	});
		
app.get('/home', function (req, res) {
		// Rendering your form
		res.render('home');
	});
app.get('/educatorhome', function (req, res) {
		// Rendering your form
		res.render('educatorhome');
	});
app.get('/AdminNew', async (req, res) =>{
		var ss=await db.collection('tbl_Educator').find({},{Name:1, _id:0});
		const arr= await ss.toArray();
	    let EduList=[];
		var i;
		for(i=0; i<arr.length; i++){
			EduList.push(arr[i].Name);
   }
   var ss1=await db.collection('tbl_Course').find({},{Course:1, _id:0});
		const arr1= await ss1.toArray();
	    let CourseList=[];
		var i;
		for(i=0; i<arr1.length; i++){
			CourseList.push(arr1[i].Course);
   }
   var ss2=await db.collection('tbl_Batches').find({},{Batch_Id:1, _id:0});
		const arr2= await ss2.toArray();
	
	    let BatchList=[];
		var i;
		for(i=0; i<arr2.length; i++){
			BatchList.push(arr2[i].Batch_Id);
   }
   
		res.render('AdminNew',{CourseList:CourseList,stulis:EduList,BatchList:BatchList});
	  });



// Handling get request
app.get('/login', function (req, res) {
	// Rendering your form
	res.render('login');
});
app.post('/AdminNew', async(req,res)=>{
	try{
		const educatorName= req.body.educator;
		var Role=req.body.check1;
		
		
		if(Role=="on"){
			Role="T"
		}
		else{
			Role="E"
		}
		const Course=req.body.course;
		
		const Batch_Id=parseInt(req.body.Batch);
		
		var id=await db.collection('tbl_Educator').findOne({Name:educatorName});
		
		var ss=await db.collection('tbl_Student').find({Batch_Id:Batch_Id},{Name:1, _id:0});
		const arr= await ss.toArray();
		
	    let EduList=[];
		var i;
		for(i=0; i<arr.length; i++){
			EduList.push(arr[i].Student_Id);
			
			var myq={Student_Id: arr[i].Student_Id, Role: Role};
			var newval={$set: {Enable:1, Course:Course, Educator_Id:id.Educator_Id }};
			db.collection("tbl_Enable_Feedback").updateOne(myq,newval,function(err,res){
				if(err) throw err;
				
		})
         }
        
		
		
		
		res.render("AdminHomePage")
	}
	catch(err){
		console.log(err);
	}

});
app.get('/AdminHomePage', function (req, res) {
	// Rendering your form
	res.render('AdminHomePage');
});

//login check
app.post('/login', async(req, res) =>{
	
	const username= req.body.Username;
    arr=username.split(".");
    if(arr[1]=="ADM"){
	try{
		
		
		const password= req.body.Password;
		const useremail = await db.collection('tbl_Admin').findOne({Username:username});
		//useremail.UserName == username && await bcrypt.compare(password, useremail.Password)
		//useremail.Password==password
		if(useremail.Password==password)
        {	
			const student_details = db.collection('tbl_Enable_Feedback');
			res.status(201).render("AdminHomePage");
			} else{
			res.send("Password not matching");
		}
	} catch(error) {
		res.status(400).send("Invalid login details")
		console.log(error);
	}}
	if(arr[1]=="TRN"){
	try{
		const username= req.body.Username;
		const password= req.body.Password;
		const useremail = await db.collection('tbl_Student').findOne({UserName:username});
		//useremail.UserName == username && await bcrypt.compare(password, useremail.Password)
		//useremail.Password==password
		if(useremail.UserName == username && await bcrypt.compare(password, useremail.Password))
        {	//tbl_Enable_Feedback
			const student_details = db.collection('tbl_Enable_Feedback');
			try{
				
				const temp = await student_details.find({Student_Id:useremail.Student_Id});
				const ans= await temp.toArray();
				const doc1 = ans[0];
				const doc2 = ans[1];
				
				global.edu_course;
				global.tech_course;
				global.edu_prog;
				global.tech_prog;
				if (doc1.Role == 'E'){
					var edu = doc1.Educator_Id;
					 edu_prog = doc1.Enable;
					edu_course=doc1.Course;
				}
				if (doc1.Role == 'T'){
					var tech = doc1.Educator_Id;
					 tech_prog = doc1.Enable;
					tech_course=doc1.Course;
				}
				if (doc2.Role == 'E'){
					var edu = doc2.Educator_Id;
					edu_prog = doc2.Enable;
					edu_course=doc2.Course;
				}
				if (doc2.Role == 'T'){
					var tech = doc2.Educator_Id;
					tech_prog = doc2.Enable;
					tech_course=doc2.Course;
				}
				
				const edu_details = await db.collection('tbl_Educator').findOne({Educator_Id:edu});
				global.edu_name= edu_details.Name;
				global.edu_des= edu_details.Designation;
				global.edu_gen= edu_details.Gender;
				global.educator_id=edu_details.Educator_Id;
				const tech_details = await db.collection('tbl_Educator').findOne({Educator_Id:tech});
				 global.tech_name= tech_details.Name;
				global.tech_des= tech_details.Designation;
				global.tech_gen= tech_details.Gender;
				global.tec_id=tech_details.Educator_Id,
				global.studentName=useremail.Name;
				global.studentId=useremail.Student_Id;
				
				res.status(201).render("home", {techcourse:tech_course, educourse:edu_course, name: useremail.Name, id:useremail.Student_Id, edu_id:edu, tec_id:tech, edu_prog:edu_prog, tech_prog:tech_prog, edu_name:edu_name, edu_des:edu_des, edu_gen:edu_gen, tech_name:tech_name, tech_des:tech_des, tech_gen:tech_gen});
			}
			catch(error){
				res.send("No Feedback Avaliable at this time");
				console.log(error);
			}
		} else{
			res.send("Password not matching");
		}
	} catch(error) {
		res.status(400).send("Invalid login details")
		console.log(error);
	}}
});
app.get('/edu_feedback', function (req, res) {
	// Rendering your form
	res.render('edu_feedback',{name:studentName,educourse:edu_course,edu_name:edu_name});
});
app.get('/tech_feedback', function (req, res) {
	// Rendering your form
	res.render('tech_feedback',{name:studentName, techcourse:tech_course,tech_name:tech_name});
});
app.get('/drop', function (req, res) {
	// Rendering your form
	res.render('drop');
});
app.post("/drop",function(req,res){
	const drop1=req.body.Manager;
	const ee=req.body.check1;

	
})

	//function (req, res) {
// Handling data after submission of form
app.post("/edu_feedback",   async(req, res) =>{
	const date1 = new Date();
	
	var r=date1.toISOString().split('T')[0];
	const feedData = new feedback_Modal({
		studentId:  studentId,
		date:r,
		educatorId: educator_id,
		subject: edu_course,
  
		presenting: req.body.presenting,
		friendly: req.body.friendly,
		efficiency: req.body.efficiency,
		Time_Utilization: req.body.Time_Utilization,
		Examples: req.body.Examples,
		Knowledge: req.body.Knowledge,
		Doubts: req.body.Doubts,
		Suggestions :req.body.Suggestions
		

	});
	console.log(req.body.Suggestions);
	feedData.save()
		.then(data => {
			
			const student_details =  db.collection('tbl_Enable_Feedback');
			
			var myq={Student_Id: studentId, Role: "E"};
			var newval={$set: {Enable:0}};
			db.collection("tbl_Enable_Feedback").updateOne(myq,newval,function(err,res){
				if(err) throw err;
				
			})
			
			edu_prog=0;
			
			
			
			res.render('home',{techcourse:tech_course, educourse:edu_course, name:studentName, id:studentId, edu_id:educator_id, tec_id:educator_id, edu_prog:edu_prog, tech_prog:tech_prog, edu_name:edu_name, edu_des:edu_des, edu_gen:edu_gen, tech_name:tech_name, tech_des:tech_des, tech_gen:tech_gen});
		})
		.catch(err => {
			console.log(err);
			
			//res.render('login',
				//{ msg: "Check Details." });
		});
});
app.post("/tech_feedback",  function (req, res) { 
	const date1 = new Date();
	
	var r=date1.toISOString().split('T')[0];
	
	const feedData2 = new feedback_Modal2({
		
		studentId:  studentId,
		date: r,
		techAssociateId: educator_id,
		subject: tech_course,
		helping: req.body.helping,
		handling: req.body.handling,
		guiding: req.body.guiding,
		DoubtClarrifying: req.body.DoubtClarrifying,
	Availability: req.body.Availability,
		Choosing: req.body.Choosing,
		
		Suggestions :req.body.Suggestions
		
		

	});
	feedData2.save()
		.then(data => {
			const student_details =  db.collection('tbl_Enable_Feedback');
			
			var myq={Student_Id: studentId, Role: "T"};
			var newval={$set: {Enable:0}};
			db.collection("tbl_Enable_Feedback").updateOne(myq,newval,function(err,res){
				if(err) throw err;
				
			})
			
			tech_prog=0;
			res.render('home',{techcourse:tech_course, educourse:edu_course, name:studentName, id:studentId, edu_id:educator_id, tec_id:educator_id, edu_prog:edu_prog, tech_prog:tech_prog, edu_name:edu_name, edu_des:edu_des, edu_gen:edu_gen, tech_name:tech_name, tech_des:tech_des, tech_gen:tech_gen}
);
		})
		.catch(err => {
			res.render('tech_feedback',
				{ msg: "Check Details." });
		});
})
app.get('/changePassword', function (req, res) {

    // Rendering your form

    res.render('changePassword');

});

app.post('/changePassword', async(req, res) =>{
    try{

		const username = req.body.username;
		const oldpassword = req.body.oldpassword;
		const useremail = await db.collection('tbl_Student').findOne({UserName:username});
		
		if(useremail.UserName == username && await bcrypt.compare(oldpassword, useremail.Password))
		{

		
			const p1= req.body.newpassword1;
			const p2= req.body.newpassword2;
			if(p1==p2)
			{

			const hashedPassword = await bcrypt.hash(req.body.newpassword1, 10);

			const UserName = req.body.username;

			

			var myquery = { UserName: UserName };

			var newvalues = { $set: {Password : hashedPassword } };
			

			db.collection("tbl_Student").updateOne(myquery, newvalues, function(err, res) {

			if (err) throw err;

				
			})

			res.render('login');

		}else{

			res.send("both passwords not matching");

		}
	}else{
		res.send("You are not a valid user. \n Username or Password are not correct.")
	}

    } catch(error) {

        res.redirect('login')

        //res.status(400).send("Invalid login details");
	}
});
app.get('/studentRegister', function (req, res) {
	// Rendering your form
	res.render('studentRegister');
});




app.post('/singleStudentRegister',async (req, res) => { 
	var ss=await db.collection('tbl_Student').find({},{Student_Id:1, _id:0});
		const ar= await ss.toArray();
	    
		var i;
		var mm=0;
		for(i=0; i<ar.length; i++){
		
		 if(mm<ar[i].Student_Id){
			 mm=ar[i].Student_Id;
		 }
   }
  
	
	try{
		   
			var Student_Id= mm+1;
			var Name = req.body.Name;
			var Batch_Id = parseInt(req.body.Batch_Id) ;
			var Password = "Infy@123";
			var UserName =  Name+".TRN";
            const hashedPassword = await bcrypt.hash(Password, 10);
			
			
		
			var data = {
				"Student_Id" : Student_Id,
				"Name" : Name,
				"Batch_Id" : Batch_Id,
				"Password" : hashedPassword,
				"UserName" : UserName
			}
	
			var enabledata1 = {
				"Student_Id":Student_Id,
				"Educator_Id": 0,
				"Enable": 0,
				"Role": "E",
				"Course":"Course"
			}
			var enabledata2 = {
				"Student_Id":Student_Id,
				"Educator_Id": 0,
				"Enable": 0,
				"Role": "T",
				"Course":"Course"
			}
			db.collection("tbl_Student").insertOne(data,function(err,collection){
				if (err) throw err
				
			})	;	
			db.collection("tbl_Enable_Feedback").insertOne(enabledata1,function(err,collection){
				if (err) throw err
				
			})	;
			db.collection("tbl_Enable_Feedback").insertOne(enabledata2,function(err,collection){
				if (err) throw err
				
			})	;	
		res.render("AdminHomePage")	

	}
	catch (error){
		console.log("error")
		}
});

app.post('/multipleStudentRegister',async (req, res) => { 

	var formData = new formidable.IncomingForm();
		formData.parse(req, async(error,fields,files)=>{
		global.filePath = files.csvfile.path;
		let url = "mongodb://localhost:27017/";
		csvtojson().fromFile(filePath).then(async(jsonObj) => {
			for(var x=0;x<jsonObj.length;x++){
				temp = parseInt(jsonObj[x].Student_Id)
				jsonObj[x].Student_Id = temp;
				temp = parseInt(jsonObj[x].Batch_Id)
				jsonObj[x].Batch_Id = temp;
				temp =	await bcrypt.hash(jsonObj[x].Password, 10);
				jsonObj[x].Password = temp;
			}
			mongodb.connect(url,{ useNewUrlParser: true, useUnifiedTopology: true },async (err, client) => {
				if (err) throw err;
				client.db("Online_Feedback_System").collection("tbl_Student").insertMany(jsonObj, (err, res) => {
					if (err) throw err;
					client.close();
				});
			});
			var jsonObj2=[];
			for(var x=0;x<jsonObj.length;x++){
				var data = {
					"Student_Id":jsonObj[x].Student_Id,
					"Educator_Id": 0,
					"Enable": 0,
					"Role": "E",
					"Course":"AI"
				}
				jsonObj2.push(data);
				var data = {
					"Student_Id":jsonObj[x].Student_Id,
					"Educator_Id": 0,
					"Enable": 0,
					"Role": "T",
					"Course":"Ml"
				}
				jsonObj2.push(data);
			}
			mongodb.connect(url,{ useNewUrlParser: true, useUnifiedTopology: true },async (err, client) => {
				if (err) throw err;
				await client.db("Online_Feedback_System").collection("tbl_Enable_Feedback").insertMany(jsonObj2, (err, res) => {
					if (err) throw err;
					client.close();
				});	
			});   
		});
	});
	res.render("AdminHomePage")

});

app.post('/multipleEducatorRegister',function (req, res) { 
	try{
	var formData = new formidable.IncomingForm();
	formData.parse(req, function(error,fields,files){
		global.filePath = files.csvfile.path;
		console.log("filename = "+filePath);
	
	let url = "mongodb://localhost:27017/";
	//console.log(filePath);
	csvtojson()
  .fromFile(filePath)
  .then((jsonObj) => {
	//console.log(jsonObj);

	console.log("Length = "+jsonObj.length);
	for(var x=0;x<jsonObj.length;x++){
		//console.log("entered")
		temp = parseInt(jsonObj[x].Educator_Id)
		jsonObj[x].Educator_Id = temp;
		temp = parseInt(jsonObj[x].Manager_Id)
		jsonObj[x].Manager_Id = temp;

	}

	console.log(jsonObj)

	mongodb.connect(
	url,
	  { useNewUrlParser: true, useUnifiedTopology: true },
	  (err, client) => {
		if (err) throw err;

		client
		  .db("Online_Feedback_System")
		  .collection("tbl_Educator")
		  .insertMany(jsonObj, (err, res) => {
			if (err) throw err;

			console.log(`Inserted: ${res.insertedCount} rows`);
			client.close();
					  });
				  }
			);
		  });
	});
	res.render("AdminHomePage")
	}
	catch(error){
		res.render("login")
	}
});
app.get('/educatorRegister', function (req, res) {
	// Rendering your form
	res.render('educatorRegister');
});
app.post('/singleEducatorRegister',async (req, res) => { 
	
	try{
			//var Educator_Id= parseInt(req.body.educatorID);
			Educator_Id=101;
			var Name = req.body.Name;
			var Manager_Id = parseInt(req.body.ManagerID ) ;
			var Password = "Infy@123";
			var UserName =  Name+".EDU";
			var Course= "AI";
            var Gender= req.body.Gender;
			
		
		var data = {
			Educator_Id :Educator_Id,
			 Name : Name,
			 Manager_Id : Manager_Id,
			 Password : Password,
			 UserName :UserName,
			 Course:Course,
             Gender:Gender
		}
		db.collection("tbl_Educator").insertOne(data,function(err,collection){
			if (err) throw err
			console.log("Record inserted successfully")
		})	;	
		res.render("AdminHomePage")	

	}
	catch (error){
		console.log("error")
		}
});

// Server setup
app.listen(port, () => {
	console.log("server is runing");
});